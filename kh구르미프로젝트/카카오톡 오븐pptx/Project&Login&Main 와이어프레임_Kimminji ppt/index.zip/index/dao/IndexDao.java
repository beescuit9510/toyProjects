package index.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import common.JDBCTemplate;
import funding.model.vo.FundingListRecent;
import table.model.vo.ProjectBasicInfo;

public class IndexDao {


	public ArrayList<FundingListRecent> productList(Connection conn, String selected) {
		PreparedStatement pstmt =null;
		ResultSet rset = null;
		ArrayList<FundingListRecent>list = new ArrayList<FundingListRecent>();
		String query= "";
		if(selected.equals("new")) {
			query = "select nn.*,(select sum(quantity)as total from PAYMENT_INFO where project_no=nn.project_no)as total \r\n" + 
					"				from (select rownum as rnum, n.* from(select a.*, b.reward_price from PROJECT_BASIC_INFO a \r\n" + 
					"				join reward b on a.project_no = b.reward_no order by project_no desc)n)nn where rnum between 1 and 12";
		}else {
			query="select  nn.*, (select sum(quantity)as total from PAYMENT_INFO where project_no=nn.project_no)as total,\r\n" + 
					"        (select count(*) from funding_like where liked_project_no=nn.project_no) as liked_count\r\n" + 
					"        from\r\n" + 
					"            (select rownum as rnum, n.* from(select a.*, b.reward_price from PROJECT_BASIC_INFO a  \r\n" + 
					"            join reward b on a.project_no = b.reward_no order by project_no desc)n)nn where rnum between 1 and 12 order by liked_count desc";
		}
		try {
			pstmt = conn.prepareStatement(query);
			rset = pstmt.executeQuery();
			while(rset.next()) {
				FundingListRecent flr = new FundingListRecent();
				flr.setProjectNo(rset.getInt("project_no"));
				flr.setBusinessNo(rset.getInt("business_no"));
				flr.setProjectTitle(rset.getString("project_title"));
				flr.setTargetPrice(rset.getInt("target_price"));
				flr.setFilepath(rset.getString("filepath"));
				flr.setEndDate(rset.getString("end_date"));
				flr.setProjectStory(rset.getString("project_story"));
				flr.setFundingCategory(rset.getString("funding_category"));
				flr.setRewardPrice(rset.getInt("reward_price"));
				flr.setTotal(rset.getInt("total"));
				list.add(flr);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				rset.close();
				pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		return list;
	}
}
