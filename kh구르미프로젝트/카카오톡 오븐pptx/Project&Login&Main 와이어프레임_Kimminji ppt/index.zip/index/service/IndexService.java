package index.service;

import java.sql.Connection;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;

import common.JDBCTemplate;
import funding.model.vo.FundingListRecent;
import index.dao.IndexDao;
import table.model.vo.ProjectBasicInfo;

public class IndexService {

	public ArrayList<FundingListRecent> productList(String selected) {
		Connection conn = JDBCTemplate.getConnection();
		ArrayList<FundingListRecent>list = new IndexDao().productList(conn,selected);
		for(FundingListRecent flr : list) {
			//날짜계산
			//DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			LocalDate now = LocalDate.now();
			//String formatedNow = now.format(formatter);
			String endDate = flr.getEndDate();
		    LocalDate date = LocalDate.parse(endDate, DateTimeFormatter.ISO_DATE);
		    //System.out.println(date);
		    //System.out.println(now);
			//System.out.println(formatedNow);
		    long period = ChronoUnit.DAYS.between(now, date);
		    flr.setPeriod(period);
		    //전체금액계산
		    int totalPrice =flr.getTotal()*flr.getRewardPrice();
		    flr.setTotalPrice(totalPrice);
		    int percent = flr.getTotalPrice()/flr.getTargetPrice()*100;
		    flr.setPercent(percent);
			System.out.println(period);
		}
		JDBCTemplate.close(conn);
		return list;
	}

}
